import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-card',
  templateUrl: './profile-card.component.html',
  styles: []
})
export class ProfileCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
